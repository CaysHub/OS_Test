// This test should XPASS, when run without valgrind.

// RUN: true
// XFAIL: valgrind
