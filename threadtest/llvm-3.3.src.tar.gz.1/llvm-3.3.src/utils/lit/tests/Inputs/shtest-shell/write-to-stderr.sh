#!/bin/sh

echo "a line on stderr" 1>&2
